# Panduan Pengembangan Custom Theme SchoolPro

Selamat datang di Starter Kit Custom Theme untuk platform SchoolPro! 
Anda sebagai developer/freelancer memiliki kebebasan penuh **100%** untuk berkreasi dalam mendesain antarmuka (UI/UX) website sekolah. Sistem kami menggunakan mesin **Handlebars (.hbs)** untuk memproses data dinamis.

---

## 🛠️ Aturan Main & Kebebasan Berkreasi

1. **Gunakan Framework Apapun**: Anda dibebaskan menggunakan murni HTML/CSS, Tailwind CSS (via CDN), Bootstrap, Bulma, atau framework CSS lainnya. Semua rancangan UI Anda akan berfungsi dengan baik.
2. **Jangan Hapus Tag Wajib**: Di dalam file `main.hbs`, pastikan tetap ada tag `{{{body}}}`. Tag ini berfungsi sebagai tempat meletakkan konten dinamis dari halaman lain (seperti `index.hbs` dll).
3. **Panggil Data dengan Handlebars**: Gunakan sintaks `{{nama_variabel}}` untuk menampilkan data dari database secara otomatis.

---

## 📂 Struktur File

Tema Anda minimal harus memiliki 2 file ini agar bisa berfungsi:
- `theme.json` (Berisi identitas tema Anda, silakan ubah nama dan author)
- `main.hbs` (Kerangka utama/Layout/Master Page yang berisi Header & Footer)
- `index.hbs` (Desain khusus halaman Beranda / Home)

### Halaman Tambahan (Opsional)
Jika Anda ingin mendesain halaman lain secara spesifik agar bentuknya tidak mengikuti bawaan sistem, Anda bisa membuat file-file berikut di dalam folder ini:
- `profil.hbs` : Halaman Tentang Kami / Profil Lembaga
- `fasilitas.hbs` : Halaman Daftar Fasilitas
- `guru.hbs` : Halaman Daftar Tenaga Pendidik / Staff
- `berita.hbs` : Halaman Daftar Berita / Artikel
- `berita-detail.hbs` : Halaman Baca Artikel Lengkap
- `galeri.hbs` : Halaman Album Foto
- `kontak.hbs` : Halaman Kontak & Maps
- `ekstrakurikuler.hbs` : Halaman Daftar Ekskul
- `program.hbs` : Halaman Program Unggulan
- `prestasi.hbs` : Halaman Prestasi Sekolah

---

## 📋 Daftar Variabel Dinamis (Cheat Sheet)

Berikut adalah daftar variabel yang bisa Anda gunakan (diapit dengan `{{ }}`):

### 1. Data Sekolah (Objek `tenant`)
- `{{tenant.name}}` = Nama Sekolah (Contoh: SMA Negeri 1 Maju)
- `{{tenant.tagline}}` = Slogan Sekolah
- `{{tenant.description}}` = Deskripsi singkat
- `{{tenant.about}}` = Sejarah atau profil panjang sekolah
- `{{tenant.logo}}` = URL gambar Logo
- `{{tenant.phone}}` = Nomor Telepon
- `{{tenant.email}}` = Email Resmi
- `{{tenant.whatsapp}}` = Nomor WhatsApp
- `{{tenant.address}}` = Alamat Lengkap
- `{{tenant.instagram}}`, `{{tenant.facebook}}`, `{{tenant.youtube}}`, `{{tenant.tiktok}}` = Link Sosmed

### 2. Pengaturan Ekstra (Objek `settings`)
- `{{settings.schoolStatus}}` = Status (NEGERI / SWASTA)
- `{{settings.studentCount}}` = Jumlah Siswa
- `{{settings.principalName}}` = Nama Kepala Sekolah
- `{{settings.principalTitle}}` = Jabatan Kepala Sekolah
- `{{settings.principalMessage}}` = Pesan/Sambutan Kepala Sekolah
- `{{settings.principalImage}}` = URL Foto Kepala Sekolah
- `{{settings.npsn}}`, `{{settings.akreditasi}}`, `{{settings.establishedYear}}`

### 3. Statistik / Angka Penting (Array `stats`)
Gunakan perulangan untuk menampilkannya:
```hbs
{{#each stats}}
  <div class="stat-card">
    <h3>{{this.value}}</h3>
    <p>{{this.label}}</p>
  </div>
{{/each}}
```

### 4. Galeri (Array `gallery`)
```hbs
{{#each gallery}}
  <img src="{{this.url}}" alt="{{this.caption}}">
{{/each}}
```

### 5. URL Dasar (Base URL)
Karena website sekolah berada di dalam sub-path, pastikan semua link internal ditambahkan variabel `{{base}}` di depannya.
- Contoh link ke halaman kontak: `<a href="{{base}}/contact">Hubungi Kami</a>`
- Contoh link ke halaman profil: `<a href="{{base}}/profil">Tentang Kami</a>`

---

## 🚀 Cara Uji Coba (Bagi Freelance)
1. Tulis kode HTML, CSS, JS Anda seperti biasa.
2. Gunakan *Live Server* di VSCode.
3. Karena data Handlebars tidak akan muncul di Live Server lokal HTML biasa, Anda bisa menggantinya sementara dengan teks statis (dummy text) saat mendesain.
4. Setelah desainnya sempurna, barulah ganti teks statis tersebut menjadi variabel Handlebars (contoh: ganti teks "SMA 1" menjadi `{{tenant.name}}`).
5. **Blok semua file (jangan masukkan ke dalam folder lagi), klik kanan -> Compress to ZIP.**
6. Berikan file `.zip` tersebut kepada klien Anda (Pemilik Aplikasi SchoolPro) untuk diunggah.

Selamat berkarya dan tunjukkan desain terbaik Anda!
