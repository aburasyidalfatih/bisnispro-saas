// Tuliskan custom Javascript Anda di sini
console.log("Theme loaded successfully.");
